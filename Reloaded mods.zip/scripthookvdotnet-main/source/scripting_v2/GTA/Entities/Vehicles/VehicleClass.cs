//
// Copyright (C) 2015 crosire & kagikn & contributors
// License: https://github.com/scripthookvdotnet/scripthookvdotnet#license
//

using System;

namespace GTA
{
    [Obsolete("The v2 API is deprecated, use the v3 API instead.")]
    public enum VehicleClass
    {
        Compacts,
        Sedans,
        SUVs,
        Coupes,
        Muscle,
        SportsClassics,
        Sports,
        Super,
        Motorcycles,
        OffRoad,
        Industrial,
        Utility,
        Vans,
        Cycles,
        Boats,
        Helicopters,
        Planes,
        Service,
        Emergency,
        Military,
        Commercial,
        Trains,
        OpenWheel,
    }
}
