# Short version for non-lawyers:
ScriptHookVDotNet is licensed under zlib license.

# Longer version:
Except as otherwise noted (below and/or in individual files), ScriptHookVDotNet is licensed under
the [zlib license](LICENSE.txt). See [THIRD-PARTY-NOTICES](THIRD-PARTY-NOTICES.md) for third party
notices for libraries used in ScriptHookVDotNet.

ScriptHookVDotNet includes portions of source code written by third parties.
The following third party source code are included, and carry their own copyright notices and
license terms:

## SlimDX
https://github.com/SlimDX/slimdx  
Portions of `Vector2`, `Vector3`, `Matrix` and `Quaternion` classes use code from SlimDX, which
carries the following license:
```
MIT License

Copyright (C) 2007-2010 SlimDX Group

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

## Chrono
https://github.com/chronotope/chrono/  
Portions of `GameClockDate`, `GameClockTime`, `GameClockDateTime`, `Internals`, `MonthDayFlags`,
`OrdFlags`, and `YearFlags` in the `GTA.Chrono` namespace use code from Chrono (for Rust), which
carry the following license:
```
The MIT License (MIT)

Copyright (c) 2014, Kang Seonghoon.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```
